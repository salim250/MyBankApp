-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  mer. 14 sep. 2022 à 04:38
-- Version du serveur :  10.1.38-MariaDB
-- Version de PHP :  7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `bank`
--

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

CREATE TABLE `client` (
  `Id` int(11) NOT NULL,
  `NumeroCompte` int(11) NOT NULL,
  `cin` int(11) NOT NULL,
  `solde` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `client`
--

INSERT INTO `client` (`Id`, `NumeroCompte`, `cin`, `solde`) VALUES
(2, 123456, 12345678, 490),
(3, 1234567, 123456789, 900),
(5, 12345, 123456, 310);

-- --------------------------------------------------------

--
-- Structure de la table `demandecartes`
--

CREATE TABLE `demandecartes` (
  `Id` int(11) NOT NULL,
  `dateDemande` datetime NOT NULL,
  `type` text,
  `etat` text,
  `clientId` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `demandecartes`
--

INSERT INTO `demandecartes` (`Id`, `dateDemande`, `type`, `etat`, `clientId`) VALUES
(1, '2022-09-13 00:37:29', 'CIB', 'rejete', 2),
(2, '2022-09-13 00:46:02', 'GOLD_MASTERCARD', 'En attente', 2);

-- --------------------------------------------------------

--
-- Structure de la table `demandechequiers`
--

CREATE TABLE `demandechequiers` (
  `Id` int(11) NOT NULL,
  `dateDemande` datetime NOT NULL,
  `nombre` int(11) NOT NULL,
  `etat` text,
  `clientId` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `demandechequiers`
--

INSERT INTO `demandechequiers` (`Id`, `dateDemande`, `nombre`, `etat`, `clientId`) VALUES
(1, '2022-09-13 01:10:12', 30, 'approuve', 2);

-- --------------------------------------------------------

--
-- Structure de la table `soldes`
--

CREATE TABLE `soldes` (
  `Id` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `operation` text,
  `montantRetire` int(11) NOT NULL,
  `montantVerse` int(11) NOT NULL,
  `clientId` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `soldes`
--

INSERT INTO `soldes` (`Id`, `date`, `operation`, `montantRetire`, `montantVerse`, `clientId`) VALUES
(1, '2022-09-12 17:27:47', 'transfert', -100, 100, 2),
(2, '2022-09-12 17:37:08', 'transfert', -100, 100, 2),
(3, '2022-09-12 17:41:10', 'transfert', -100, 100, 2),
(4, '2022-09-12 17:42:59', 'virement', -100, 100, 2),
(5, '2022-09-12 19:08:22', 'virement', -10, 10, 2),
(6, '2022-09-12 22:03:39', 'virement', -100, 100, 2),
(7, '2022-09-12 22:06:25', 'virement', -10, 10, 2),
(8, '2022-09-12 22:10:06', 'virement', -10, 10, 2),
(9, '2022-09-12 22:11:17', 'virement', -10, 10, 2),
(10, '2022-09-12 22:13:00', 'virement', -10, 10, 2),
(11, '2022-09-12 22:14:56', 'virement', -10, 10, 2),
(12, '2022-09-12 22:18:49', 'virement', -10, 10, 2),
(13, '2022-09-13 17:51:50', 'transfert', -100, 100, 2),
(14, '2022-09-13 17:56:52', 'transfert', -10, 10, 2);

-- --------------------------------------------------------

--
-- Structure de la table `transferts`
--

CREATE TABLE `transferts` (
  `Id` int(11) NOT NULL,
  `montant` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `clientDebiteurId` int(11) DEFAULT NULL,
  `clientRecepteurId` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `transferts`
--

INSERT INTO `transferts` (`Id`, `montant`, `date`, `clientDebiteurId`, `clientRecepteurId`) VALUES
(1, 100, '2022-09-12 17:20:49', 2, 5),
(2, 100, '2022-09-12 17:27:47', 2, 5),
(3, 100, '2022-09-12 17:37:07', 2, 5),
(4, 100, '2022-09-12 17:41:09', 2, 5),
(5, 100, '2022-09-13 17:51:49', 2, 5),
(6, 10, '2022-09-13 17:56:52', 2, 5);

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `Id` int(11) NOT NULL,
  `nom` text,
  `prenom` text,
  `password` text,
  `role` text NOT NULL,
  `Email` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`Id`, `nom`, `prenom`, `password`, `role`, `Email`) VALUES
(1, 'brahim', 'salim', 'salim', 'admin', 'salim@gmail.com'),
(2, 'brahim', 'jihen', 'jihen', 'client', 'jihen@gmail.com'),
(3, 'brahim', 'mohamed', '123', 'client', 'mohamed@gmail.com'),
(5, 'brahim', 'ahmed', '1234', 'client', 'ahmed@gmail.com'),
(6, 'bourouissi', 'ines', '1234', 'agent', 'ines@gmail.com'),
(7, 'bouzidi', 'nour', '1234', 'chef', 'nour@gmail.com');

-- --------------------------------------------------------

--
-- Structure de la table `virements`
--

CREATE TABLE `virements` (
  `Id` int(11) NOT NULL,
  `compteDebiteur` int(11) NOT NULL,
  `compteACrediter` int(11) NOT NULL,
  `montant` int(11) NOT NULL,
  `motif` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `virements`
--

INSERT INTO `virements` (`Id`, `compteDebiteur`, `compteACrediter`, `montant`, `motif`) VALUES
(1, 123456, 12345678, 100, 'espece'),
(2, 123456, 12345, 10, 'espece'),
(3, 123456, 12345, 100, 'espece'),
(4, 123456, 12345, 10, 'espece'),
(5, 123456, 12345, 10, 'espece'),
(6, 123456, 12345, 10, 'espece'),
(7, 123456, 12345, 10, 'espece'),
(8, 123456, 12345, 10, 'espece'),
(9, 123456, 12345, 10, 'espece');

-- --------------------------------------------------------

--
-- Structure de la table `__efmigrationshistory`
--

CREATE TABLE `__efmigrationshistory` (
  `MigrationId` varchar(150) NOT NULL,
  `ProductVersion` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `__efmigrationshistory`
--

INSERT INTO `__efmigrationshistory` (`MigrationId`, `ProductVersion`) VALUES
('20220912142615_InitialCreate', '6.0.0-preview.3.21201.2'),
('20220912144120_SecondMigration', '6.0.0-preview.3.21201.2'),
('20220912161343_thirdMigration', '6.0.0-preview.3.21201.2');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`Id`),
  ADD UNIQUE KEY `IX_Client_NumeroCompte` (`NumeroCompte`);

--
-- Index pour la table `demandecartes`
--
ALTER TABLE `demandecartes`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `IX_DemandeCartes_clientId` (`clientId`);

--
-- Index pour la table `demandechequiers`
--
ALTER TABLE `demandechequiers`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `IX_DemandeChequiers_clientId` (`clientId`);

--
-- Index pour la table `soldes`
--
ALTER TABLE `soldes`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `IX_Soldes_clientId` (`clientId`);

--
-- Index pour la table `transferts`
--
ALTER TABLE `transferts`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `IX_Transferts_clientDebiteurId` (`clientDebiteurId`),
  ADD KEY `IX_Transferts_clientRecepteurId` (`clientRecepteurId`);

--
-- Index pour la table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`Id`);

--
-- Index pour la table `virements`
--
ALTER TABLE `virements`
  ADD PRIMARY KEY (`Id`);

--
-- Index pour la table `__efmigrationshistory`
--
ALTER TABLE `__efmigrationshistory`
  ADD PRIMARY KEY (`MigrationId`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `client`
--
ALTER TABLE `client`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `demandecartes`
--
ALTER TABLE `demandecartes`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `demandechequiers`
--
ALTER TABLE `demandechequiers`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `soldes`
--
ALTER TABLE `soldes`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT pour la table `transferts`
--
ALTER TABLE `transferts`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT pour la table `user`
--
ALTER TABLE `user`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT pour la table `virements`
--
ALTER TABLE `virements`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `client`
--
ALTER TABLE `client`
  ADD CONSTRAINT `FK_Client_User_Id` FOREIGN KEY (`Id`) REFERENCES `user` (`Id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `demandecartes`
--
ALTER TABLE `demandecartes`
  ADD CONSTRAINT `FK_DemandeCartes_Client_clientId` FOREIGN KEY (`clientId`) REFERENCES `client` (`Id`);

--
-- Contraintes pour la table `demandechequiers`
--
ALTER TABLE `demandechequiers`
  ADD CONSTRAINT `FK_DemandeChequiers_Client_clientId` FOREIGN KEY (`clientId`) REFERENCES `client` (`Id`);

--
-- Contraintes pour la table `soldes`
--
ALTER TABLE `soldes`
  ADD CONSTRAINT `FK_Soldes_Client_clientId` FOREIGN KEY (`clientId`) REFERENCES `client` (`Id`);

--
-- Contraintes pour la table `transferts`
--
ALTER TABLE `transferts`
  ADD CONSTRAINT `FK_Transferts_Client_clientDebiteurId` FOREIGN KEY (`clientDebiteurId`) REFERENCES `client` (`Id`),
  ADD CONSTRAINT `FK_Transferts_Client_clientRecepteurId` FOREIGN KEY (`clientRecepteurId`) REFERENCES `client` (`Id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
